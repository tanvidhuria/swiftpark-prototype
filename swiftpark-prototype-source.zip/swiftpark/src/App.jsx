import { useState, useEffect, useRef } from 'react'

/* ------------------------------------------------------------------ *
 * SwiftPark — prototype for the two builds prioritised before the
 * city-wide expansion:
 *   Build 1 · backlog #2 — Automated no-show release
 *   Build 2 · backlog #3 — Warden app stability + offline mode
 *
 * Visual language, zones, spot codes and pricing are carried over from
 * the live pilot builds so this reads as the next version of SwiftPark
 * rather than a redesign. Everything is local state — no backend.
 * ------------------------------------------------------------------ */

const HOLD_SECONDS = 15 * 60

const FLOWS = {
  driver: {
    tag: 'Build 1 · #2',
    name: 'Automated no-show release',
    who: 'Driver app',
    states: [
      { id: 'holding', label: 'Spot held — grace period running' },
      { id: 'arrived', label: 'Arrival confirmed' },
      { id: 'released', label: 'Spot released — expired or cancelled' },
    ],
  },
  warden: {
    tag: 'Build 2 · #3',
    name: 'Warden app: stability + offline',
    who: 'Warden app',
    states: [
      { id: 'board', label: 'Active bookings — Zone 3' },
      { id: 'spot', label: 'Spot detail — log an action' },
      { id: 'logged', label: 'Logged actions — offline queue' },
    ],
  },
}

const NOTES = {
  holding: {
    title: 'The booking finally has an expiry',
    found:
      'In the live app a booking is made and then nothing else ever happens to it. There is no cancel option in My Bookings — a driver who knows they cannot come has no way to give the spot back.',
    body: [
      'A 15-minute grace window the driver can see. One tap confirms arrival. If nothing happens by the time the clock runs out, the spot returns to the pool on its own.',
      'The second button is the cancel path the current build is missing. Some share of that 40% are people who tried to do the right thing and had nowhere to do it.',
    ],
    metric: ['Peak-hour utilisation', '47%', '≥70% in 4 weeks'],
  },
  arrived: {
    title: 'The first arrival event SwiftPark has ever had',
    found:
      'The current driver flow ends at payment. There is no screen after it, and no point anywhere in the product where the system learns a car is actually in the bay.',
    body: [
      'This one tap is worth more than it looks. Until it exists, the 40% no-show figure is inferred from sensors that are 87% accurate, and a driver whose spot was stolen is indistinguishable from one who never came.',
      'It is also why I would not build the penalty system Finance asked for yet. We would be fining people on a number nobody has verified.',
    ],
    metric: ['Verified no-show rate', '40% inferred', '<15% measured'],
  },
  released: {
    title: 'Inventory comes back — and the count actually moves',
    found:
      'Booking a spot in the live build does not take it out of circulation. The zone still reads 18 of 24 available afterwards and the spot stays green in the grid.',
    body: [
      'The bay goes back and the zone counter moves with it. That is the whole revenue argument: the Zone 2 manager watches 30–40% of bays sit physically empty at peak while the app turns walk-ins away with a Full sign.',
      'The two routes here are treated differently on purpose. A driver who cancels inside their window gets a straight refund — they did us a favour. A hold that runs out in silence comes back as credit rather than being forfeited, because we have not earned the right to charge anyone yet.',
    ],
    metric: ['Spots returned per peak hour', '0 today', 'tracked from day 1'],
  },
  board: {
    title: 'A warden can finally tell what has expired',
    found:
      'The live board shows "09:00 · 2 hrs" and the spot detail shows Booked From and Duration. It never shows when a booking ends, so a warden standing in the bay at 11:15 has to do the arithmetic in their head. The counter row also reads 0 total while listing eight bookings.',
    body: [
      'Every row carries the end time and how long is left. Expired holds sort to the top, because those are the bays that should already be back on sale.',
      'I also replaced Unverified — a status the current app never explains — with Awaiting arrival, which says what it means and what the warden is waiting for. Tap any row to work it.',
    ],
    metric: ['Warden app usage', '23%', '≥80% in 3 weeks'],
  },
  spot: {
    title: 'The action the wardens said they did not have',
    found:
      'The live spot detail offers exactly two actions: Confirm Valid Booking and Flag Unauthorised Vehicle. There is no option for the case the wardens described — a booking exists and the bay is empty.',
    body: [
      'A warden told us plainly that nobody explained what to do when the driver never showed, so they waved the next car in and it never reached the system. Three actions now, and the middle one is the one that was missing.',
      'This is not a new enforcement workflow. It is the warden confirming or correcting a release that Build 1 already decided — the sensor is right 87% of the time and the warden is standing in front of it.',
    ],
    metric: ['Spot conflict rate', '18%', '<5% in 4 weeks'],
  },
  logged: {
    title: 'Losing signal stops being a reason to stop working',
    found:
      'The live app already flashes "No network detected — actions will sync when online", but it crashes at least twice a shift, and opening Logged Actions traps you on a screen you have to press Back to escape even though it is a tab.',
    body: [
      'Every action you log lands here with the spot it belonged to and whether it has been sent. Logged Actions is a real tab you can leave the way you came in.',
      'Flip the connection on in the panel and watch the queue drain.',
    ],
    metric: ['Field record reaches the system', 'end of shift', '<15 min'],
  },
}

const INITIAL_BOOKINGS = [
  { spot: 'A-03', name: 'Deepak Nair', from: '08:45', to: '10:45', status: 'expired', note: 'Hold expired 22 min ago', amt: '₹120', vehicle: 'KA-01-HK-2214' },
  { spot: 'B-03', name: 'Arjun Singh', from: '10:30', to: '11:30', status: 'await', note: 'Ends in 12 min · no arrival yet', amt: '₹40', vehicle: 'MH-12-MN-6789' },
  { spot: 'B-04', name: 'Meera Krishnan', from: '09:45', to: '11:45', status: 'await', note: 'Ends in 27 min · no arrival yet', amt: '₹50', vehicle: 'KA-03-AB-9931' },
  { spot: 'A-01', name: 'Priya Sharma', from: '09:00', to: '11:00', status: 'active', note: 'Arrival confirmed 09:04', amt: '₹60', vehicle: 'KA-05-MJ-1120' },
  { spot: 'B-01', name: 'Suresh Pillai', from: '09:15', to: '11:15', status: 'active', note: 'Arrival confirmed 09:19', amt: '₹60', vehicle: 'KA-02-CD-4407' },
]

const PILL_TEXT = {
  active: 'Confirmed',
  await: 'Awaiting arrival',
  expired: 'Hold expired',
  released: 'Released',
  flagged: 'Flagged',
}

const ACTIONS = {
  confirm: { label: 'Booking confirmed — correct vehicle', status: 'active', note: 'Confirmed by warden' },
  release: { label: 'No-show confirmed — spot released', status: 'released', note: 'Released back to the pool' },
  flag: { label: 'Unauthorised vehicle flagged', status: 'flagged', note: 'Unauthorised vehicle reported' },
}

const fmt = (t) =>
  `${String(Math.max(0, Math.floor(t / 60))).padStart(2, '0')}:${String(Math.max(0, t % 60)).padStart(2, '0')}`

const clockNow = () =>
  new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true }).toLowerCase()

export default function App() {
  const [flow, setFlow] = useState('driver')
  const [state, setState] = useState('holding')

  /* driver */
  const [secs, setSecs] = useState(HOLD_SECONDS)
  const [reason, setReason] = useState('expired') // 'expired' | 'cancelled'
  const timer = useRef(null)

  /* warden */
  const [offline, setOffline] = useState(true)
  const [bookings, setBookings] = useState(INITIAL_BOOKINGS)
  const [selected, setSelected] = useState(INITIAL_BOOKINGS[1].spot)
  const [log, setLog] = useState([
    { id: 0, spot: 'A-03', text: 'Unauthorised vehicle flagged', time: '06:51:08 pm', synced: false },
  ])

  useEffect(() => {
    if (!(flow === 'driver' && state === 'holding')) return
    timer.current = setInterval(() => {
      setSecs((s) => {
        if (s <= 1) {
          clearInterval(timer.current)
          setReason('expired')
          setState('released')
          return 0
        }
        return s - 1
      })
    }, 1000)
    return () => clearInterval(timer.current)
  }, [flow, state])

  const queued = log.filter((l) => !l.synced).length

  useEffect(() => {
    if (!offline && queued > 0) {
      const t = setTimeout(() => setLog((ls) => ls.map((l) => ({ ...l, synced: true }))), 1100)
      return () => clearTimeout(t)
    }
  }, [offline, queued])

  function go(f, s) {
    setFlow(f)
    setState(s)
    if (f === 'driver' && s === 'holding') setSecs(HOLD_SECONDS)
  }

  function cancelBooking() {
    setReason('cancelled')
    setState('released')
  }

  function logAction(kind) {
    const a = ACTIONS[kind]
    setBookings((bs) =>
      bs.map((b) => (b.spot === selected ? { ...b, status: a.status, note: `${a.note} at ${clockNow().slice(0, 5)}` } : b)),
    )
    setLog((ls) => [{ id: Date.now(), spot: selected, text: a.label, time: clockNow(), synced: !offline }, ...ls])
    setState('logged')
  }

  function resetShift() {
    setBookings(INITIAL_BOOKINGS)
    setLog([{ id: 0, spot: 'A-03', text: 'Unauthorised vehicle flagged', time: '06:51:08 pm', synced: false }])
    setOffline(true)
    setSelected(INITIAL_BOOKINGS[1].spot)
    setState('board')
  }

  const cfg = FLOWS[flow]
  const note = NOTES[state]
  const urgent = secs <= 120
  const booking = bookings.find((b) => b.spot === selected) || bookings[0]

  return (
    <div className="shell">
      <header className="masthead">
        <p className="eyebrow">SwiftPark · Product Owner assignment · Deliverable 4</p>
        <h1>Two builds, six states, one problem</h1>
        <p>
          A booking in SwiftPark is a promise the system never checks and nobody enforces. These
          screens close that loop from both ends — the driver tells us they arrived, and the warden
          can act when they didn't. The design, zones and pricing are carried over from the live
          pilot builds; the notes on the right flag what I found while walking through them.
        </p>
      </header>

      <div className="switch" role="group" aria-label="Choose a build">
        {Object.entries(FLOWS).map(([key, f]) => (
          <button key={key} aria-pressed={flow === key} onClick={() => go(key, f.states[0].id)}>
            <span className="tag">{f.tag}</span>
            {f.name}
          </button>
        ))}
      </div>

      <div className="stage">
        <nav className="rail" aria-label="Screens">
          <p className="rail-title">{cfg.who}</p>
          {cfg.states.map((s, i) => (
            <button key={s.id} aria-current={state === s.id} onClick={() => go(flow, s.id)}>
              <span className="num">{String(i + 1).padStart(2, '0')}</span>
              <span>{s.label}</span>
            </button>
          ))}
        </nav>

        <div className="phone">
          <div className="screen">
            {flow === 'driver' ? (
              <DriverApp
                state={state}
                secs={secs}
                urgent={urgent}
                reason={reason}
                go={(s) => go('driver', s)}
                onCancel={cancelBooking}
              />
            ) : (
              <WardenApp
                state={state}
                offline={offline}
                bookings={bookings}
                booking={booking}
                log={log}
                queued={queued}
                go={(s) => setState(s)}
                onOpen={(spot) => {
                  setSelected(spot)
                  setState('spot')
                }}
                onLog={logAction}
              />
            )}
          </div>
        </div>

        <div className="notes">
          <div className="note">
            <h4>{note.title}</h4>
            <p className="found">
              <b>In the current build: </b>
              {note.found}
            </p>
            {note.body.map((p, i) => (
              <p key={i}>{p}</p>
            ))}
            <div className="metric">
              <span>{note.metric[0]}</span>
              <b>{note.metric[1]}</b>
              <span className="arrow">→</span>
              <b>{note.metric[2]}</b>
            </div>
          </div>

          <div className="note">
            <h4>Controls for whoever is reviewing this</h4>
            <p>Nobody should have to wait fifteen minutes to see the interesting part.</p>
            <div className="helper">
              {flow === 'driver' && state === 'holding' && (
                <>
                  <button onClick={() => setSecs(8)}>Jump to 00:08</button>
                  <button onClick={() => setSecs(HOLD_SECONDS)}>Reset clock</button>
                </>
              )}
              {flow === 'driver' && state !== 'holding' && (
                <button onClick={() => go('driver', 'holding')}>Restart the booking</button>
              )}
              {flow === 'warden' && (
                <>
                  <button className="toggle" aria-pressed={offline} onClick={() => setOffline((o) => !o)}>
                    <span className="track">
                      <i />
                    </span>
                    {offline ? 'Signal is off' : 'Signal is on'}
                  </button>
                  <button onClick={resetShift}>Reset the shift</button>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      <p className="footnote">
        <b>What I deliberately left out.</b> No login, no zone map, no payment or refund processing,
        no live sensor feed, no dynamic pricing, no zone-manager dashboard. Both builds are really
        about state changing over time — a hold that expires on its own, an action that survives a
        dead connection — so I built the parts that actually run that logic and skipped the
        scaffolding that would have hidden it. Built in React and Vite rather than a design tool,
        because a linked-frames prototype can only mime a countdown; this one runs it.
      </p>
      <p className="footnote">
        <b>Also found but not fixed here.</b> The booking form accepts a start time in the past and
        will take a booking with no end time at all (Duration reads "NaN hour", Total reads "₹NaN").
        The available-spots list shows ten entries when the zone header says eighteen are free. Walk
        distance is shown where driving distance is what a driver in a car needs. The 4hr+ chip
        breaks the pattern the +1hr/+2hr/+3hr chips set. All real, none of them the reason the pilot
        is underperforming — they go to the backlog, not into one of two build slots.
      </p>
    </div>
  )
}

/* ================================ DRIVER ================================ */

function DriverApp({ state, secs, urgent, reason, go, onCancel }) {
  const cancelled = reason === 'cancelled'
  const title =
    state === 'holding' ? 'Your booking' : state === 'arrived' ? 'Parked' : cancelled ? 'Booking cancelled' : 'Hold expired'
  return (
    <>
      <div className="statusbar">
        <span>9:41</span>
        <span>SwiftPark</span>
        <span>▮▮▮</span>
      </div>
      <div className="appbar">
        <span className="zone">Zone 1 — MG Road</span>
        <div className="titlerow">
          <h2>
            {state !== 'holding' && (
              <button className="back" onClick={() => go('holding')} aria-label="Back">
                ←
              </button>
            )}
            {title}
          </h2>
        </div>
        <p className="counts">{state === 'released' ? '19 of 24 available' : '18 of 24 available'}</p>
      </div>

      {state === 'holding' && <DriverHolding secs={secs} urgent={urgent} go={go} onCancel={onCancel} />}
      {state === 'arrived' && <DriverArrived />}
      {state === 'released' && <DriverReleased cancelled={cancelled} go={go} />}

      <nav className="tabbar">
        <button>
          <span className="ico">⌂</span>Home
        </button>
        <button aria-current="true">
          <span className="ico">▤</span>Bookings
        </button>
        <button>
          <span className="ico">◍</span>Profile
        </button>
      </nav>
    </>
  )
}

function DriverHolding({ secs, urgent, go, onCancel }) {
  return (
    <div className="scroll">
      <div className="card">
        <div className="spothead">
          <span className="badge">D5</span>
          <div>
            <h3>Spot D5</h3>
            <p className="sub">Zone 1 — MG Road · Open Air</p>
          </div>
        </div>
        <div className="grid2">
          <div className="box">
            <span>Booked from</span>
            <b>7:15 PM</b>
          </div>
          <div className="box">
            <span>Booked till</span>
            <b>9:15 PM</b>
          </div>
          <div className="box">
            <span>Paid</span>
            <b>₹70 · 2 hours</b>
          </div>
          <div className="box new">
            <span>Held until</span>
            <b>7:30 PM</b>
          </div>
        </div>
        <div style={{ marginTop: 11 }}>
          <span className={`pill ${urgent ? 'expired' : 'await'}`}>
            <span className="dot" />
            {urgent ? 'About to be released' : 'Held for you'}
          </span>
        </div>
      </div>

      <div className={`countdown ${urgent ? 'urgent' : ''}`}>
        <div className="clock">{fmt(secs)}</div>
        <p className="cap">
          {urgent
            ? 'Confirm now or D5 goes back to other drivers.'
            : 'We hold your spot for 15 minutes from the time your booking starts.'}
        </p>
        <div className="meter">
          <span style={{ width: `${(secs / HOLD_SECONDS) * 100}%` }} />
        </div>
      </div>

      <div className="btnstack">
        <button className="btn good" onClick={() => go('arrived')}>
          I've arrived and parked
        </button>
        <button className="btn ghost" onClick={onCancel}>
          Cancel booking and release my spot
        </button>
      </div>

      <p className="fixnote">
        <b>New here:</b> the hold clock, and a cancel option. The live app has neither — once you
        pay, the bay is yours whether or not you ever turn up.
      </p>
    </div>
  )
}

function DriverArrived() {
  return (
    <div className="scroll">
      <div className="banner good">
        <span>
          <strong>Arrival confirmed</strong>
          Wardens can see this booking is genuine. Nobody will move you on.
        </span>
      </div>

      <div className="card">
        <div className="spothead">
          <span className="badge">D5</span>
          <div>
            <h3>Spot D5</h3>
            <p className="sub">Zone 1 — MG Road</p>
          </div>
        </div>
        <div style={{ marginTop: 11 }}>
          <span className="pill active">
            <span className="dot" />
            Confirmed
          </span>
        </div>
        <dl style={{ margin: '13px 0 0' }}>
          <div className="kv">
            <dt>Confirmed at</dt>
            <dd className="mono">7:16 PM</dd>
          </div>
          <div className="kv">
            <dt>Leave by</dt>
            <dd className="mono">9:15 PM</dd>
          </div>
          <div className="kv">
            <dt>Paid</dt>
            <dd className="mono">₹70</dd>
          </div>
          <div className="kv">
            <dt>Booking ID</dt>
            <dd className="mono">SP76471</dd>
          </div>
        </dl>
      </div>

      <div className="card">
        <p className="label">Something wrong?</p>
        <p style={{ margin: 0, fontSize: 12, color: 'var(--muted)', lineHeight: 1.55 }}>
          If another vehicle is in D5, tell us and it lands on a Zone 1 warden's board straight away
          instead of at the end of their shift.
        </p>
      </div>

      <div className="btnstack">
        <button className="btn bad">Report another car in my spot</button>
      </div>
    </div>
  )
}

function DriverReleased({ cancelled, go }) {
  return (
    <div className="scroll">
      <div className="banner info">
        <span>
          <strong>{cancelled ? 'Booking cancelled' : 'Your hold has ended'}</strong>
          {cancelled
            ? 'D5 is back with other drivers. Your ₹70 has been refunded to the card you paid with.'
            : 'D5 is back with other drivers. Your ₹70 is now SwiftPark credit.'}
        </span>
      </div>

      <div className="card">
        <p className="label">What happened</p>
        <p style={{ margin: 0, fontSize: 12.5, color: 'var(--muted)', lineHeight: 1.6 }}>
          {cancelled
            ? 'You released D5 yourself, before your hold ran out. It went straight back into the pool — two drivers were searching Zone 1 at the time. Because you told us, you get a full refund rather than credit.'
            : 'We held D5 for 15 minutes from 7:15 PM and did not hear that you had arrived, so it went back into the pool. Two drivers were searching Zone 1 at the time.'}
        </p>
      </div>

      <div className="card flush">
        <div className="sectionhead">
          <h3>Free now in Zone 1 — MG Road</h3>
          <span className="count">19 of 24</span>
        </div>
        <div className="rows">
          {[
            ['D5', 'Just released · ~2 min walk', '₹35/hr'],
            ['A2', 'Open Air · ~3 min walk', '₹35/hr'],
            ['C4', 'Open Air · ~4 min walk', '₹35/hr'],
          ].map(([code, meta, rate]) => (
            <button className="row" key={code}>
              <span className="badge active">{code}</span>
              <span className="main">
                <span className="name">Spot {code}</span>
                <span className="meta">{meta}</span>
              </span>
              <span className="right">
                <span className="amt">{rate}</span>
              </span>
            </button>
          ))}
        </div>
      </div>

      <div className="btnstack">
        <button className="btn">{cancelled ? 'Book another spot' : 'Book again using my credit'}</button>
        <button className="btn ghost" onClick={() => go('holding')}>
          ← Back to the hold screen
        </button>
      </div>

      <p className="fixnote">
        <b>New here:</b> the zone counter moved from 18 to 19. In the live build, booking a spot
        never takes it out of circulation and releasing one is not possible at all.
      </p>
    </div>
  )
}

/* ================================ WARDEN ================================ */

function WardenApp({ state, offline, bookings, booking, log, queued, go, onOpen, onLog }) {
  const n = (st) => bookings.filter((b) => b.status === st).length
  return (
    <>
      <div className="statusbar">
        <span>07:17 pm</span>
        <span>{offline ? 'NO NETWORK' : 'ONLINE'}</span>
        <span>WD-042</span>
      </div>
      <div className="appbar">
        <span className="zone">Zone 3 — Indiranagar</span>
        <div className="titlerow">
          <h2>
            {state === 'spot' && (
              <button className="back" onClick={() => go('board')} aria-label="Back">
                ←
              </button>
            )}
            {state === 'spot' ? `Spot ${booking.spot}` : state === 'logged' ? 'Logged actions' : 'Active bookings'}
          </h2>
          <span className="shift">
            Shift
            <b>02:17:44</b>
          </span>
        </div>
        <p className="counts">
          {n('active')} confirmed · {n('await')} awaiting · {n('expired')} expired · {n('released')} released ·{' '}
          {bookings.length} total
        </p>
      </div>

      {state === 'board' && <WardenBoard offline={offline} bookings={bookings} onOpen={onOpen} />}
      {state === 'spot' && <WardenSpot booking={booking} onLog={onLog} />}
      {state === 'logged' && <WardenLogged offline={offline} log={log} queued={queued} />}

      <nav className="tabbar">
        <button aria-current={state !== 'logged'} onClick={() => go('board')}>
          <span className="ico">▤</span>Active bookings
        </button>
        <button aria-current={state === 'logged'} onClick={() => go('logged')}>
          <span className="ico">✓</span>Logged actions
          {queued > 0 && <span className="badgecount">{queued}</span>}
        </button>
      </nav>
    </>
  )
}

function WardenBoard({ offline, bookings, onOpen }) {
  const order = { expired: 0, await: 1, flagged: 2, active: 3, released: 4 }
  const sorted = [...bookings].sort((a, b) => order[a.status] - order[b.status])
  return (
    <div className="scroll">
      {offline && (
        <div className="banner offline">
          <span>
            <strong>No network — keep going</strong>
            Everything you log is saved on this phone and sent the moment you have signal.
          </span>
        </div>
      )}

      <div className="card flush">
        <div className="rows">
          {sorted.map((b) => (
            <button className="row" key={b.spot} onClick={() => onOpen(b.spot)}>
              <span className={`badge ${b.status}`}>{b.spot}</span>
              <span className="main">
                <span className="name">{b.name}</span>
                <span className="meta">
                  {b.from}–{b.to} · {b.note}
                </span>
              </span>
              <span className="right">
                <span className={`pill ${b.status}`}>{PILL_TEXT[b.status]}</span>
                <span className="amt">{b.amt}</span>
              </span>
            </button>
          ))}
        </div>
      </div>

      <p className="fixnote">
        <b>New here:</b> every row shows when the booking ends, not just how long it ran for. The
        live board shows "09:00 · 2 hrs" and leaves the warden to work out whether 11:15 is inside
        or outside that. The counter row adds up now too. Tap any row to work it.
      </p>
    </div>
  )
}

function WardenSpot({ booking, onLog }) {
  const done = ['active', 'released', 'flagged'].includes(booking.status)
  return (
    <div className="scroll">
      <div className="card">
        <div className="spothead">
          <span className={`badge ${booking.status}`}>{booking.spot}</span>
          <div>
            <h3>Spot {booking.spot}</h3>
            <p className="sub">Zone 3 — Indiranagar</p>
          </div>
        </div>
        <div style={{ marginTop: 11 }}>
          <span className={`pill ${booking.status}`}>
            <span className="dot" />
            {PILL_TEXT[booking.status]}
          </span>
        </div>
      </div>

      <div className="card">
        <p className="label">Booking details</p>
        <dl style={{ margin: 0 }}>
          <div className="kv">
            <dt>Driver</dt>
            <dd>
              {booking.name} · {booking.vehicle}
            </dd>
          </div>
          <div className="kv">
            <dt>Booked</dt>
            <dd className="mono">
              {booking.from} – {booking.to} · {booking.amt} paid
            </dd>
          </div>
          <div className="kv hi">
            <dt>Status</dt>
            <dd>{booking.note}</dd>
          </div>
          <div className="kv">
            <dt>Sensor reading</dt>
            <dd>{booking.status === 'active' ? 'Vehicle detected' : 'No vehicle detected'}</dd>
          </div>
        </dl>
        <p style={{ margin: '11px 0 0', fontSize: 11.5, color: 'var(--muted)', lineHeight: 1.5 }}>
          The sensor is right about 87% of the time. You are standing in front of the bay — you
          decide.
        </p>
      </div>

      {done && (
        <div className="banner good">
          <span>
            <strong>Already logged this shift</strong>
            You can still change your mind — logging again overwrites the last action for this bay.
          </span>
        </div>
      )}

      <div className="btnstack">
        <button className="btn good" onClick={() => onLog('confirm')}>
          ✓ Correct vehicle is parked here
        </button>
        <button className="btn warn" onClick={() => onLog('release')}>
          Bay is empty — release the spot
        </button>
        <button className="btn bad" onClick={() => onLog('flag')}>
          ! Wrong vehicle is parked here
        </button>
      </div>

      <p className="fixnote">
        <b>New here:</b> the end time, and the middle button. The live app gives a warden Confirm
        Valid Booking and Flag Unauthorised Vehicle — and nothing at all for the case they told us
        about, where the booking exists and the bay is empty.
      </p>
    </div>
  )
}

function WardenLogged({ offline, log, queued }) {
  return (
    <div className="scroll">
      <div className={`banner ${queued > 0 ? 'offline' : 'good'}`}>
        <span>
          <strong>{queued > 0 ? 'Saved on this phone' : 'Everything is sent'}</strong>
          {queued > 0
            ? offline
              ? 'You have not lost any of this. It goes out by itself the moment you have signal.'
              : 'Back online — sending now.'
            : 'The zone manager and the council dashboard are already showing it.'}
        </span>
      </div>

      <div className="card flush">
        <div className="sectionhead">
          <h3>This shift</h3>
          <span className="count">
            {log.length} action{log.length === 1 ? '' : 's'} · {queued > 0 ? `${queued} waiting` : 'all sent'}
          </span>
        </div>
        <div className="rows">
          {log.map((it) => (
            <div className="row" key={it.id}>
              <span className={`badge ${it.synced ? 'active' : 'await'}`}>{it.spot}</span>
              <span className="main">
                <span className="name">{it.text}</span>
                <span className="meta">
                  Spot {it.spot} · {it.time}
                </span>
              </span>
              <span className="right">
                <span className={`pill ${it.synced ? 'active' : 'mute'}`}>{it.synced ? 'Sent' : 'Waiting'}</span>
              </span>
            </div>
          ))}
        </div>
      </div>

      <p className="fixnote">
        <b>New here:</b> this is a tab you can leave by tapping the other tab. In the live app,
        opening Logged Actions strands you until you press the browser Back button. Switch the
        signal on in the panel to watch the queue clear.
      </p>
    </div>
  )
}
